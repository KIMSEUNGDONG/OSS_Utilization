/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jaspersoft.ireport.addons.background;

import org.netbeans.api.visual.widget.LayerWidget;
import org.netbeans.api.visual.widget.Scene;

/**
 *
 * @version $Id: BackgroundImageWidget.java 0 2010-01-12 16:19:25 CET gtoffoli $
 * @author Giulio Toffoli (giulio@jaspersoft.com)
 *
 */
public class BackgroundImageLayer extends LayerWidget {

    public BackgroundImageLayer(Scene scene)
    {
        super(scene);
    }
}
